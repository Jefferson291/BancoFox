package BancoFox;
public class Pessoa {
	
	String Nome, END, Bairro, cidade, Email, idade, Tel, Login, Senha;
	double Saldo  = 10000;
	double R;
	
	
	
}
